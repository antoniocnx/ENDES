package es.iessoterohernandez.daw.endes.pruebaJUnit;

public class SaldoInsuficienteException extends Exception {
	
		public SaldoInsuficienteException(String message) {
			super(message);
		}
}
