package cuentas;

public class IngresoNegativoException extends Exception{
	public IngresoNegativoException(String message) {
		super(message);
	}
}
